<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "marine_research_db";
$port = 3308;

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname, $port);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
