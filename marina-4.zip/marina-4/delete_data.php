<?php
include 'db.php';
session_start();

if (!isset($_SESSION['researcher_id'])) {
    header("Location: login.php");
    exit();
}

if (isset($_GET['data_id'])) {
    $data_id = $_GET['data_id'];

    // Delete the record from the database
    $sql = "DELETE FROM sensor_data WHERE id='$data_id'";

    if ($conn->query($sql) === TRUE) {
        header("Location: index.php?msg=Data deleted successfully");
    } else {
        echo "Error deleting record: " . $conn->error;
    }
} else {
    echo "Invalid request.";
}

$conn->close();
?>
