<?php
include 'db.php';
session_start();

if (!isset($_SESSION['researcher_id'])) {
    header("Location: index.php");
    exit();
}

if (!isset($_GET['data_id'])) {
    echo "Error: Data ID not specified.";
    exit();
}

$data_id = $_GET['data_id'];

$sql = "SELECT sensor_id, value FROM sensor_data WHERE id='$data_id'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $sensor_id = $row['sensor_id'];
    $value = $row['value'];
} else {
    echo "No data found";
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $new_value = $_POST['value'];

    $sql = "UPDATE sensor_data SET value='$new_value' WHERE id='$data_id'";

    if ($conn->query($sql) === TRUE) {
        $message = "Data updated successfully";
    } else {
        $message = "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Data</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Optional JavaScript -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
<?php include 'navbar.php'; ?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h4>Edit Data</h4>
                </div>
                <div class="card-body">
                    <?php if (isset($message)): ?>
                        <div class="alert alert-info"><?php echo $message; ?></div>
                    <?php endif; ?>
                    <form method="post" action="edit_data.php?data_id=<?php echo $data_id; ?>">
                        <div class="mb-3">
                            <label for="sensor" class="form-label">Sensor</label>
                            <select class="form-control" id="sensor" name="sensor_id" disabled>
                                <option value="">Select Sensor</option>
                                <?php
                                $sql = "SELECT sensors.id, sensors.type, buoys.id AS buoy_id, buoys.deployment_date
                                        FROM sensors
                                        JOIN buoys ON sensors.buoy_id = buoys.id";
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) {
                                    while($row = $result->fetch_assoc()) {
                                        $selected = ($row['id'] == $sensor_id) ? "selected" : "";
                                        echo "<option value='" . $row['id'] . "' $selected>Sensor " . $row['id'] . " (" . $row['type'] . ") on Buoy " . $row['buoy_id'] . " (Deployed on " . $row['deployment_date'] . ")</option>";
                                    }
                                }
                                ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="value" class="form-label">Value</label>
                            <input type="text" class="form-control" id="value" name="value" value="<?php echo $value; ?>" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Edit Data</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
