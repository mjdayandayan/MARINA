<?php
include 'db.php';
session_start();

if (!isset($_SESSION['researcher_id'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Marine Research Dashboard</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="custom.css">
    <!-- Optional JavaScript -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
<?php include 'navbar.php'; ?>
<div class="container mt-5">
    <?php if (isset($_GET['msg'])): ?>
        <div class="alert alert-info"><?php echo htmlspecialchars($_GET['msg']); ?></div>
    <?php endif; ?>
    <div class="row">
        <div class="col-md-12">
            <h4>Sensor Data</h4>
            <table class="table table-bordered">
                <thead>
                <tr>
                    <th>Data ID</th>
                    <th>Buoy ID</th>
                    <th>Value</th>
                    <th>Timestamp</th>
                    <th>Actions</th>
                </tr>
                </thead>
                <tbody>
                <?php
                $sql = "SELECT sensor_data.id, sensors.buoy_id, sensor_data.value, sensor_data.timestamp
                        FROM sensor_data
                        JOIN sensors ON sensor_data.sensor_id = sensors.id";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        echo "<tr>
                            <td>" . $row['id'] . "</td>
                            <td>" . $row['buoy_id'] . "</td>
                            <td>" . $row['value'] . "</td>
                            <td>" . $row['timestamp'] . "</td>
                            <td>
                                <a class='btn btn-warning' href='edit_data.php?data_id=" . $row['id'] . "'>Edit</a>
                                <a class='btn btn-danger' href='delete_data.php?data_id=" . $row['id'] . "' onclick='return confirm(\"Are you sure you want to delete this data?\")'>Delete</a>
                            </td>
                        </tr>";
                    }
                } else {
                    echo "<tr><td colspan='5'>No data found</td></tr>";
                }
                ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <h4>Buoys</h4>
            <table class="table table-bordered">
                <thead>
                <tr>
                    <th>Buoy ID</th>
                    <th>Location ID</th>
                    <th>Deployment Date</th>
                    <th>Actions</th>
                </tr>
                </thead>
                <tbody>
                <?php
                $sql = "SELECT id, location_id, deployment_date FROM buoys";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        echo "<tr>
                            <td>" . $row['id'] . "</td>
                            <td>" . $row['location_id'] . "</td>
                            <td>" . $row['deployment_date'] . "</td>
                            <td>
                                <a class='btn btn-warning' href='edit_buoy.php?buoy_id=" . $row['id'] . "'>Edit</a>
                                <a class='btn btn-danger' href='delete_buoy.php?buoy_id=" . $row['id'] . "' onclick='return confirm(\"Are you sure you want to delete this buoy?\")'>Delete</a>
                            </td>
                        </tr>";
                    }
                } else {
                    echo "<tr><td colspan='4'>No buoys found</td></tr>";
                }
                ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</body>
</html>
